"use strict";

for(let i =0; i < 10; i++) {
  console.log("Hello " + i);
}

console.log("The value of i is: " + i);

