const DIGITS = 10;
function adder(x) {
  return DIGITS + x;
}

export default adder;

