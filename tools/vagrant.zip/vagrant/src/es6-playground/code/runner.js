import adder from './adder';

console.log(adder(2));

