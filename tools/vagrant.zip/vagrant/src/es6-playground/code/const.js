"use strict";

const value = "hello";
value = "goodbye";

