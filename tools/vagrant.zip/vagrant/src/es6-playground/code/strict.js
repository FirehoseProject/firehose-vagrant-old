"use strict";

console.log("I'm using strict mode");

