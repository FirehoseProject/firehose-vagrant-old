"use strict";

const values = [
  "hello",
  "goodbye",
  "good day"
]

for(let value of values) {
  console.log(value);
}
